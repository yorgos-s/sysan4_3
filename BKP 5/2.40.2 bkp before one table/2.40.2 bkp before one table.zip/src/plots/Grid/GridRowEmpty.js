import React from 'react'

const GridRowEmpty = ({h}) => {
  return (
    // <tr style={{height:'0.2em'}}></tr>
    <tr style={{height:`${h}em`}}></tr>
  )
}

export default GridRowEmpty