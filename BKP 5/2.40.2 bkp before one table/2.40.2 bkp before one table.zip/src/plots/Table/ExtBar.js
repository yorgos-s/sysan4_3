import React from 'react'

const ExtBar = () => {
  return (
    <div>
        {/* <button></button>
        <h1>hi</h1> */}
    </div>
  )
}

export default ExtBar