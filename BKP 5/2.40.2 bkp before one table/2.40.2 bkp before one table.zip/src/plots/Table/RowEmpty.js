import React from 'react'

const RowEmpty = () => {
  return (
    <tr style={{height:'0.7em'}}></tr>
  )
}

export default RowEmpty